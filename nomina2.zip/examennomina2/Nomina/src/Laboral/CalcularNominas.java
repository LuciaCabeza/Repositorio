package Laboral;
package main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CalcularNominas {

	public static void main(String[] args) {

		/**
		 * Dentro del metodo main debemos hacer que nos coja la excepcion, 
		 * ademas de crear los nuevos empleados que nos piden, y ponerle los incrementos 
		 * y las asignaciones necesarias.
		 */
		try {//Inicializamos la excepcion para ty-catch para poder conprobar los parametros.
			//Creamos nuevos empleados con sus respectivos parametros.
			Empleado james = new Empleado("James Cosling", "48124096T", 'M', 4,7);
			Empleado ada = new Empleado("Ada Lovelace","48811600B",'F');
			
			escribe(james, ada);
			
			//Hacemos un incremento de años a ada.
			ada.incrAnyos();
			
			//Le asignamos a james la categoria 9.
			james.setCategoria(9);
			
			//Escribimos los empleados para poder comprobar que hemos puesto bien los apartados.
			escribe(james,ada);
		/*
		 * Si los nuevos empleados no estan bien puestos debemos hace que nos salte una excepcion
		 * que nos diga que hemos introducido mal los parametros
		 */
		}catch (DatosIncorrectosException escribe) {//Hacemos que reciba la excepcion de manera que escriba si esta bien o no los datos
			
			System.out.println(escribe.toString());
		
		}

		
	}
	/**
	 * Creamos un metodo aparte del main donde pintaremos el resultado final del codigo despues de cambiar el codigo anteriormente
	 * @param emp1
	 * @param emp2
	 */
	private static void escribe(Empleado emp1, Empleado emp2) {
		
		System.out.println(emp1.imprime()+",sueldo:"+ Nomina.sueldo(emp1));
		System.out.println(emp2.imprime()+",sueldo:"+ Nomina.sueldo(emp2));

	}
	
	public static void main(String[] args) throws SQLException, IOException {
		
		//Creación de la conexion a la base de datos
		final String direccion = "jdbc:mysql://localhost:3306/agenda"; 
		final String usuario = "root";
		final String contrasena = "Asdfghjk1@";
		Connection con = DriverManager.getConnection(direccion, usuario, contrasena);

		//Creamos un statement para asi poder ejecutar el select o Query que deseemos sobre la base de datos.
		Statement stmt;
		
		//Un simple insert en la tabla agenda.
				stmt = con.createStatement();
				String query = "insert into empleado values('nombre1', '22345654U', 'h')";
		        stmt.executeUpdate(query);		
				
		        //Preparamos la querry para el select sobre empleado
				String select = "select * from empledo";
				
				//Guardamos el resultado en un Result set que mas adelante trabajemos con los datos del select
				ResultSet rs = stmt.executeQuery(select);
				
				//Creamos un fichero
				File f = new File("Prueba");
				
				//Creamos un writter para el fichero
				FileWriter fwr = new FileWriter(f, true); //El booleano es true si quiero sobreescribir y false si quiero que se borre el contenido y se cree otro nuevo
				BufferedWriter bwr = new BufferedWriter(fwr);
				
				//Un bucle para recoger los campos del select, getTipo(nombre_columna) y escribirlos directamente en el fichero.
				//NOTA: He dejado las columnas asi separadas para que podais distinguir correctamente cada campo, podeis concatenarlo todo en un solo writter.
				while (rs.next()) {
					bwr.write(rs.getString("nombre"));
					bwr.write(" ");
					bwr.write(rs.getString("dni"));
					bwr.write(" ");
					bwr.write(rs.getString("sexo"));
					bwr.write(" ");
					
				}

				
				//Cerramos todos los buffers, writters, conexiones
				bwr.close();
				fwr.close();
				stmt.close();
				con.close();
				
				//Creacion de un escaner para leer el fichero
				Scanner sc = new Scanner(f);
				
				//Leemos el fichero linea por linea
				while(sc.hasNext()) {
					System.out.println(sc.nextLine());
				}
				
				sc.close();
			}
	}
}
