package laboral;

public class Empleado extends Persona{
	
	
		//variables
		private int categoria;
		public int anyos;
		
		//metodos
		//constructor
		public Empleado(int categoria, int anyos ) {
			this.categoria=categoria;
			this.anyos=anyos;
			super(){
				this.nombre=nombre;
				this.dni=dni;
				this.sexo=sexo;
			}
		}
		public void setCategoria(int categoria){
			
		}
		public int getCategoria() {
			return categoria;
		}
		public int incrAnyo(int anyos) {
			anyos++;
			return anyos;
			
		}
		public String imprime() {
			return("El empleado "+nombre+" con dni, "+dni+" de sexo "+sexo+" esta en la categoria "+categoria+ " tiene "+anyos+" años");
		}
	}

}
