package laboral;

public class Nomina {
	
		//variables
		private static final int SUELDO_BASE[]= {50000,70000,90000,110000,130000,150000,170000,190000,210000,230000}
		
		//metodos
		public void sueldo(Empleado) {
			int sueldoBase=SUELDO_BASE[categoria-1];
			int sueldo=sueldoBase+5000*anyos;
			return sueldo;
		}
		public void
	
	}

