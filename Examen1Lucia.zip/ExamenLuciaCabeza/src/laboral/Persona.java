package laboral;

public class Persona {
	 
		//variables
		String nombre, dni;
		char sexo;
		
		//metodos
		
		//constructor
		
	public Persona(String nombre, String dni, char sexo) {
		this.nombre=nombre;
		this.dni=dni;
		this.sexo=sexo;
		}
	
	public Persona(String nombre, char sexo) {
		this.nombre=nombre;
		this.sexo=sexo;
	}
	
	public String setDni() {
		return dni;
	}
	
	public String imprime() {
		return "El nombre es "+nombre+" el dni es "+ dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	 }
	

