package laboral;

public class Main {

}
